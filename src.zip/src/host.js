var url="https://backend-school-0u75.onrender.com"
module.exports=url