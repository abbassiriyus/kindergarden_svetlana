import React from 'react'
import Img1 from '../img/free-icon-daughter-8229500.png'
import Img2 from '../img/free-icon-kindergarden-5235725 1.png'

export default function Page5() {
  return (
    <div className='Page5niki'>
       <div className='kids-Page2'>
        <div className='kid-Page2'>
          <div className='asd'>
            <img src={Img1} alt='' />
            <div className='kid-prfl'>
              <h4>Маринина Наташа</h4>
              <p>4 года</p>
              <h3 className='volss'>
                <img src={Img2} alt='' />
                Волшебник 2 уровня
              </h3>
            </div>
          </div>
        </div>
      </div>

    </div>
  )
}
