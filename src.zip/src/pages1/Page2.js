import React from 'react'
import './AllPages.css'
import Table from 'react-bootstrap/Table'
/* import 'bootstrap/dist/css/bootstrap.min.css' */
import Dropdown from 'react-bootstrap/Dropdown'

export default function Page2 () {
  return (
    <div className='The-Big'>
      <div className='Big-Page2'>
        <div className='data-group'>
          <select>
            <option>Малинина Виктория Петровна</option>
            <option>Малинина Виктория Петровна2</option>
            <option>Малинина Виктория Петровна3</option>
          </select>
          <input type='date' />
        </div>
        <div id='tables'>
          <div id='names'>
            <p></p>
            <p>ПН</p>
            <p>ВТ</p>
            <p>СР</p>
            <p>ЧТ</p>
            <p>ПТ</p>
            <p>СБ</p>
            <p>ВС</p>
          </div>
          <div id='inform1'>
            <div id='iconci'>
              <p>09.00 - 09.25</p>
            </div>
          </div>

          <div id='inform2'>
            <div id='inform-p'>
              <p>09.35 - 10.00</p>
              <p>
                Волшебник 1 уровня <br />
                Эмоции каб.2
              </p>
              <p>
                Волшебник 2 уровня <br />
                Эмоции каб.2
              </p>
              <p></p>
              <p></p>
              <p></p>
              <p>
                Волшебник 1 уровня <br />
                Эмоции каб.2
              </p>
              <div id='iconci'></div>
            </div>
          </div>
          <div id='inform1'>
            <div id='inform-p'>
              <p>09.35 - 10.00</p>
              <p>
                Волшебник 1 уровня <br />
                Эмоции каб.2
              </p>
              <p>
                Волшебник 2 уровня <br />
                Эмоции каб.2
              </p>
              <p></p>
              <p></p>
              <p></p>
              <p>
                Волшебник 1 уровня <br />
                Эмоции каб.2
              </p>
              <div id='iconci'></div>
            </div>
          </div>
          <div id='inform2'>
            <div id='iconci'>
              <p>09.00 - 09.25</p>
            </div>
          </div>
          <div id='inform1'>
            <div id='inform-p'>
              <p>09.35 - 10.00</p>
              <p>
                Волшебник 1 уровня <br />
                Эмоции каб.2
              </p>
              <p>
                Волшебник 2 уровня <br />
                Эмоции каб.2
              </p>
              <p></p>
              <p></p>
              <p></p>
              <p>
                Волшебник 1 уровня <br />
                Эмоции каб.2
              </p>
              <div id='iconci'></div>
            </div>
          </div>
          <div id='inform2'>
            <div id='iconci'>
              <p>09.00 - 09.25</p>
            </div>
          </div>
          <div id='inform1'>
            <div id='iconci'>
              <p>09.00 - 09.25</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
