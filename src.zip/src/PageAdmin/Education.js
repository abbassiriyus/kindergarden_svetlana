import * as React from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import '../css/Education.css'

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export default function BasicTabs() {
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <div>
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
           <a href='/Educations'><Tab label="Обучение" {...a11yProps(2)} /></a>
           <a href='/'><Tab label="Медицинское заключение" {...a11yProps(2)} /></a>
           <a href='/'><Tab label="Документы" {...a11yProps(2)} /></a>
        </Tabs>
      </Box>
    </Box>
    <div className="nodir91">
          <div className='bigagroup'>
          <div className="group">
               <p className="jk">Группа * </p>
               <select className='eilish' name="" id="">
                  <option value=""></option>
                  <option value="">billie</option>
               </select>
            </div>
            <div className="group2">
               <p className="jk">Дата зачисления * </p>
               <select className='eilish' name="" id="">
                  <option value=""></option>
                  <option value="">billie</option>
               </select>
            </div>
            <div className="group3">
               <p className="jk">Дата отчисления </p>
               <select className='eilish' name="" id="">
                  <option value=""></option>
                  <option value="">billie</option>
               </select>
            </div>
          </div>
           <div className='bigagroup1'>
           <div className="group4">
               <p className="jk"> Программа обучения </p>
               <select className='eilish' name="" id="">
                  <option value=""></option>
                  <option value="">billie</option>
               </select>
            </div>
            <div className="group5">
               <p className="jk">Доп.занятия </p>
               <select className='eilish' name="" id="">
                  <option value=""></option>
                  <option value="">billie</option>
               </select>
            </div>
            <div className="group6">
               <p className="jk"> Воспитатель</p>
               <select className='eilish' name="" id="">
                  <option value=""></option>
                  <option value="">billie</option>
               </select>
            </div>
         </div>
         <div className="bn">
 <a href='/Groupchill'><button className="happier">Назад</button></a>
   <button className="happier2">
   Сохранить
   </button>
</div>
           </div>
</div>
  )
}