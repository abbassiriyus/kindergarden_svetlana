
import '../css/New.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { Component } from 'react'
import ico1 from '../icon2.svg'
import ico2 from '../icon1.svg'
export default class App extends Component {
  render() {
    return (
<div className="nodir5">
<div className="cake">
   <div className="cake1">
      <select className='mad' name="" id="">
         <option value="">Группа</option>
         <option value="">Группа</option>
         <option value="">Группа</option>
         <option value="">Группа</option>
      </select>
      <input className='mad' type="date" placeholder='Дата добавления' />
      <button className="nodiruca">
         + Добавить ребенка
      </button>
   </div>
</div>

           <div className=" bigbox">  
                        <div className="bodyadmpn" >

                   <div className="btnadmp_box1">
                        <table className="btnchil_table">
                          <tr className="btnadmp_tr">
       
                             <th className="btnadmp_th1">ID</th>
                             
                             <th className="btnadmp_th"> Фамилия</th>
                             <th className="btnadmp_th">Имя</th>
                             <th className="btnadmp_th">Отчество</th>
                             <th className="btnadmp_th">Дата  <br />рождения</th>
                             <th className="btnadmp_th">Пол</th>
                             <th className="btnadmp_th">Дата  <br /> добавления</th>
                             <th className="btnadmp_th2">Действие </th>
                 
                         
                          </tr>
                             
      
                           
                              <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1">1 </td>
                             <td className="btnadmp_td1">Малинина </td>
                             <td className="btnadmp_td1"> Наташа </td>
                             <td className="btnadmp_td1">Евгеньевна</td>
                             <td className="btnadmp_td1">15/07/2020  </td>
                             <td className="btnadmp_td1">ж </td>
                             <td className="btnadmp_td1"> 15/07/2022  </td>
                
                   

                             <td className="btnadmp_td1"> 
                             <button className="butadmp1"><img src={ico2} alt=""  /></button>
                                 <button className="butadmp2"><img src={ico1} alt=""  /></button>
                             </td>
                                </tr>
                          
                                <tr  className="btnadmp_tr1" >
                                  <td className="btnadmp_td2"> 2 </td>
                             <td className="btnadmp_td2">Малинин</td>
                             <td className="btnadmp_td2"> Егор</td>
                             <td className="btnadmp_td2">Евгеньевич</td>
                             <td className="btnadmp_td2">20/03/2017</td>
                             <td className="btnadmp_td2">м  </td>
                             <td className="btnadmp_td2"> 15/07/2020 </td>
<td className="btnadmp_td2"> 
                             <button className="butadmp1"><img src={ico2} alt=""  /></button>
                                 <button className="butadmp2"><img src={ico1} alt=""  /></button>
                             </td>
                                </tr>
                        
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1"></td>
                             <td className="btnadmp_td1"></td>

                             <td className="btnadmp_td1"> 
                             <button className="butadmp1"><img src={ico2} alt=""  /></button>
                                 <button className="butadmp2"><img src={ico1} alt=""  /></button>
                             </td>
                                </tr>
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"> </td>
                             <td className="btnadmp_td2">  </td>
                             <td className="btnadmp_td2">  </td>

                             <td className="btnadmp_td2"> 
                             <button className="butadmp1"><img src={ico2} alt=""  /></button>
                                 <button className="butadmp2"><img src={ico1} alt=""  /></button>
                             </td>
                                </tr>
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1"></td>
                             <td className="btnadmp_td1"></td>

                             <td className="btnadmp_td1"> 
                             <button className="butadmp1"><img src={ico2} alt=""  /></button>
                                 <button className="butadmp2"><img src={ico1} alt=""  /></button>
                             </td>
                                </tr>

                            
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"> </td>
                             <td className="btnadmp_td2">  </td>
                             <td className="btnadmp_td2">  </td>
<td className="btnadmp_td2"> 
                             <button className="butadmp1"><img src={ico2} alt=""  /></button>
                                 <button className="butadmp2"><img src={ico1} alt=""  /></button>
                             </td>
                                </tr>
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1"> </td>     
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1"></td>
                             <td className="btnadmp_td1"></td>

                             <td className="btnadmp_td1"> 
          
                             </td>
                                </tr>
                          
                    
                            
                           
                     
                        </table>
                   </div>
            </div>
           </div>

</div>
          )
        }
      
      }