import React, { Component } from 'react'
import img from '../img/free-icon-user-149071 1.png'
export default class Nastroyka extends Component {
  render() {
    return (
      <div className='nastroyka_all'>
<div className="nastroyka_user">

<img src={img} alt="" />
    <div class="formbold-file-input">
    <input type="file" name="file" id="file" />
    <label for="file">
    <div>
    <span class="formbold-browse"> Сменить фото </span>
    </div>
    </label>
    </div>
    </div>
 

<div className="nastroyka_input">
<label htmlFor="">Фамилия </label><br />
<input type="text" value="Солнцева" name="" id="" /><br />
<label htmlFor="">Имя</label><br />
<input type="text" value="Татьяна" name="" id="" /><br />
<label htmlFor="">Отчество</label><br />
<input type="text" value="Николаевна" name="" id="" /><br />
<label htmlFor="">Дата рождения</label><br />
<input type="date" value="1979-12-20" name="" id="" /><br />
<label htmlFor="">Улица</label><br />
<input type="text" value="Аткарская" name="" id="" /><br />
<label htmlFor="">Дом</label><br />
<input type="number" value="50" name="" id="" /><br />            
<label htmlFor="">Квартира</label><br />
<input type="number" value="60" name="" id="" /><br />              
<label htmlFor="">Номер телефона</label><br />
<input type="tel" value="+7987-333-33-33" name="" id="" /><br />  
<label htmlFor="">E-mail</label><br />
<input type="email" value="rew@mail.ru" name="" id="" /><br />                 
                

                
                

                
                

                
                
</div>
      </div>
    )
  }
}
