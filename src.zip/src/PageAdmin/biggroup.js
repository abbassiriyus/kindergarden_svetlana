import '../css/biggroup.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { Component } from 'react'
import icon1 from '../icon1.svg'
import icon2 from '../icon2.svg'
export default class App extends Component {
  render() {
    return (
<div className="nodir53">
<div className="cake3">
   <div className="cake1245">
      <select className='mad245' name="" id="">
         <option value="">Учебный год</option>
         <option value="">Учебный год</option>
         <option value="">Учебный год</option>
         <option value="">Учебный год</option>
      </select>

      <button className="nodiruca345">
         +Добавить группу
      </button>
   </div>
</div>

           <div className=" bigbox">  
                        <div className="bodyadmpn" >

                   <div className="btnadmp_box1">
                        <table className="btnchil_table">
                          <tr className="btnadmp_tr">
       
                             <th className="btnadmp_th1">ID</th>
                             
                             <th className="btnadmp_th"> Название</th>
                             <th className="btnadmp_th">Учебный год</th>
                             <th className="btnadmp_th">Воспитатели</th>
                             <th className="btnadmp_th">Активность</th>
                            
                             <th className="btnadmp_th2">Действие </th>

                          </tr>

                              <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1">1 </td>
                             <td className="btnadmp_td1">  Волшебник 1 уровня  </td>
                             <td className="btnadmp_td1">2021/2022  </td>
                             <td className="btnadmp_td1">Маринина Вероника Петровна  Столова Мария Геннадьевна</td>
                             <td className="btnadmp_td1">Да</td>
     

                             <td className="btnadmp_td1"> 
                             <button className="butadmp1"><img src={icon2} alt=""  /></button>
                                 <button className="butadmp2"><img src={icon1} alt=""  /></button>
                             </td>
                                </tr>
                          
                                <tr  className="btnadmp_tr1" >
                                  <td className="btnadmp_td2"> 2 </td>
                             <td className="btnadmp_td2">   Волшебник 2 уровня </td>
                             <td className="btnadmp_td2">  2021/2022 </td>
                             <td className="btnadmp_td2"> Маринина Вероника Петровна</td>
                             <td className="btnadmp_td2">Да</td>
                            

               <td className="btnadmp_td2"> 
                             <button className="butadmp1"><img src={icon2} alt=""  /></button>
                                 <button className="butadmp2"><img src={icon1} alt=""  /></button>
                             </td>
                                </tr>
                        
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1"> 3</td>
                             <td className="btnadmp_td1">  Волшебник 1 уровня  </td>
                             <td className="btnadmp_td1">  2021/2022 </td>
                             <td className="btnadmp_td1"> Максимова Наталья Петровна Абрикосова Мария Алексеевна</td>
                             <td className="btnadmp_td1"> Да</td>
<td className="btnadmp_td1"> 
                             <button className="butadmp1"><img src={icon2} alt=""  /></button>
                                 <button className="butadmp2"><img src={icon1} alt=""  /></button>
                             </td>
                                </tr>
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"> </td>
                          

                             <td className="btnadmp_td2"> 
                             <button className="butadmp1"><img src={icon2} alt=""  /></button>
                                 <button className="butadmp2"><img src={icon1} alt=""  /></button>
                             </td>
                                </tr>
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1">   </td>
                         

                             <td className="btnadmp_td1"> 
                             <button className="butadmp1"><img src={icon2} alt=""  /></button>
                                 <button className="butadmp2"><img src={icon1} alt=""  /></button>
                             </td>
                                </tr>

                            
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"> </td>
                             <td className="btnadmp_td2">  </td>
              
             

                             <td className="btnadmp_td2"> 
                             <button className="butadmp1"><img src={icon2} alt=""  /></button>
                                 <button className="butadmp2"><img src={icon1} alt=""  /></button>
                             </td>
                                </tr>
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1"> </td>     
                             <td className="btnadmp_td1"> </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1">  </td>
                       
         

                             <td className="btnadmp_td1"> 
                  
                             </td>
                                </tr>
                        </table>
                   </div>
            </div>
           </div>

</div>
          )
        }
      
      }