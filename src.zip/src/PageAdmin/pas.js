import React, { Component } from 'react'
import ico1 from '../icon1.svg'
import ico2 from '../icon2.svg'
import '../css/pas.css'

export default class pas extends Component {
  render() {
    return (
      <div>
<div className="nodir4">


            <div className=" bigbox">
               <div className="bodyadmpn" >

                  <div className="btnadmp_box1">
                     <table className="btnchil_table">
                        <tr className="btnadmp_tr">

                           <th className="btnadmp_th1">ID</th>

                           <th className="btnadmp_th">Дата добавления </th>
                           <th className="btnadmp_th">Дата</th>
                           <th className="btnadmp_th"> Ребенок </th>
                           <th className="btnadmp_th">Причина </th>
                           <th className="btnadmp_th">Автор </th>
                           <th className="btnadmp_th2">Действие</th>

                        </tr>



                        <tr className="btnadmp_tr1" >
                           <td className="btnadmp_td1">1</td>
                           <td className="btnadmp_td1">2022/12/12 08:00</td>
                           <td className="btnadmp_td1"> 2022/12/12  </td>
                           <td className="btnadmp_td1">Малинина Наташа</td>
                           <td className="btnadmp_td1"> Болезнь   </td>
                           <td className="btnadmp_td1"> Маринина В.П. </td>


                           <td className="btnadmp_td1">
                              <button className="butadmp1"><img src={ico2} alt="" /></button>
                              <button className="butadmp2"><img src={ico1} alt="" /></button>
                           </td>
                        </tr>

                        <tr className="btnadmp_tr1" >
                           <td className="btnadmp_td2">2</td>
                           <td className="btnadmp_td2">2022/12/12 08:00  </td>
                           <td className="btnadmp_td2">2022/12/12 </td>
                           <td className="btnadmp_td2"> Малинин Егор </td>
                           <td className="btnadmp_td2"> Болезнь</td>
                           <td className="btnadmp_td2">Маринина В.П. </td>
                           <td className="btnadmp_td2">
                              <button className="butadmp1"><img src={ico2} alt="" /></button>
                              <button className="butadmp2"><img src={ico1} alt="" /></button>
                           </td>
                        </tr>

                        <tr className="btnadmp_tr1" >
                           <td className="btnadmp_td1">3</td>
                           <td className="btnadmp_td1">2022/12/12   08:00   </td>
                           <td className="btnadmp_td1"> 2022/12/12 </td>
                           <td className="btnadmp_td1"> Звонков Максим  </td>
                           <td className="btnadmp_td1">Болезнь  </td>
                           <td className="btnadmp_td1">Маринина В.П.  </td>
                           <td className="btnadmp_td1">
                              <button className="butadmp1"><img src={ico2} alt="" /></button>
                              <button className="butadmp2"><img src={ico1} alt="" /></button>
                           </td>
                        </tr>
                        <tr className="btnadmp_tr1" >
                           <td className="btnadmp_td1"></td>
                           <td className="btnadmp_td1"> </td>
                           <td className="btnadmp_td1">   2022/12/13   </td>
                           <td className="btnadmp_td1">Звонков Максим </td>
                           <td className="btnadmp_td1"> Болезнь </td>
                           <td className="btnadmp_td1"> Маринина В.П. </td>

                           <td className="btnadmp_td1">

                           </td>
                        </tr>
<tr className="btnadmp_tr1" >
                           <td className="btnadmp_td1"></td>
                           <td className="btnadmp_td1"> </td>
                           <td className="btnadmp_td1"> 2022/12/14  </td>
                           <td className="btnadmp_td1">Звонков Максим </td>
                           <td className="btnadmp_td1"> Болезнь </td>
                           <td className="btnadmp_td1"> Маринина В.П. </td>

                           <td className="btnadmp_td1">

                           </td>
                        </tr>


                        <tr className="btnadmp_tr1" >
                           <td className="btnadmp_td1"></td>
                           <td className="btnadmp_td1"> </td>
                           <td className="btnadmp_td1"> 2022/12/14  </td>
                           <td className="btnadmp_td1">Звонков Максим </td>
                           <td className="btnadmp_td1"> Болезнь </td>
                           <td className="btnadmp_td1"> Маринина В.П. </td>

                           <td className="btnadmp_td1">

                           </td>
                        </tr>

                        <tr className="btnadmp_tr1" >
                           <td className="btnadmp_td2"></td>
                           <td className="btnadmp_td2">  </td>
                           <td className="btnadmp_td2"> </td>
                           <td className="btnadmp_td2">  </td>
                           <td className="btnadmp_td2"></td>
                           <td className="btnadmp_td2"></td>
                           <td className="btnadmp_td2">

                           </td>
                        </tr>
                        <tr className="btnadmp_tr1" >
                           <td className="btnadmp_td1"></td>
                           <td className="btnadmp_td1"> </td>
                           <td className="btnadmp_td1">  </td>
                           <td className="btnadmp_td1"> </td>
                           <td className="btnadmp_td1"></td>
                           <td className="btnadmp_td1"> </td>

                           <td className="btnadmp_td1">

                           </td>
                        </tr>



                     </table>
                  </div>
               </div>
            </div>

         </div>
      </div>
    )
  }
}
