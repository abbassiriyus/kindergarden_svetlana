import React, { Component } from 'react'
// import 'bootstrap/dist/css/bootstrap.min.css';
// import Dropdown from 'react-bootstrap/Dropdown';
import icon1 from '../img/free-icon-kindergarden-5235725 1.png'
import './AllAdmin.css'

export default class Listchill extends Component {
  render() {
    return (
      <div>
        <h1 className='bigah1'>Заявки</h1>
            <div className="biga-pages">
            </div>
            <div id='tables'>
                <div id='names'>
                    <p>ID</p>
                    <p>Имя</p>
                    <p>Эл.почта</p>
                    <p>Отчество</p>
                    {/* <p>Дети</p> */}
                    {/* <p>Телефон</p> */}
                    <p>Дата <br/> поступления</p>
                    <p>Примичения</p>

                </div>
                <div id='inform1'>
                    <div id='inform-p'>
                        <p>1</p>
                        <p>Ирина</p>
                        <p>adf@yandex.ru</p>
                        <p>+7(910)134-56-22</p>
                        <p>15/07/2020</p>
                        <div id='iconci'>
                            <img src={icon1} alt='' />
                            {/* <img src={icon2} alt='' /> */}
                        </div>
                    </div>
                </div>

                <div id='inform2'>
                    <div id='inform-p1'>
                        {/* <p>4</p>
                        <p>Смирнова</p>
                        <p>Вероника</p>
                        <p>Петровна</p>
                        <p>20/03/1986</p>
                        <p>Воспитатель</p>
                        <p>15/07/2020</p> */}
                        <div id='iconci1'>
                            <img src={icon1} alt='' />
                            {/* <img src={icon2} alt='' /> */}
                        </div>
                    </div>
                </div>
                <div id='inform1'>
                    <div id='inform-p1'>
                        {/* <p>5</p>
                        <p>Тарелкина</p>
                        <p>Вероника</p>
                        <p>Петровна</p>
                        <p>20/03/1986</p>
                        <p>Воспитатель</p>
                        <p>15/07/2020</p> */}
                        <div id='iconci1'>
                            <img src={icon1} alt='' />
                            {/* <img src={icon2} alt='' /> */}
                        </div>
                    </div>
                </div>

                <div id='inform2'>
                    <div id='inform-p1'>
                        {/* <p>4</p>
                        <p>Смирнова</p>
                        <p>Вероника</p>
                        <p>Петровна</p>
                        <p>20/03/1986</p>
                        <p>Воспитатель</p>
                        <p>15/07/2020</p> */}
                        <div id='iconci1'>
                            <img src={icon1} alt='' />
                            {/* <img src={icon2} alt='' /> */}
                        </div>
                    </div>
                </div>

                <div id='inform1'>
                    <div id='inform-p1'>
                        {/* <p>5</p>
                        <p>Тарелкина</p>
                        <p>Вероника</p>
                        <p>Петровна</p>
                        <p>20/03/1986</p>
                        <p>Воспитатель</p>
                        <p>15/07/2020</p> */}
                        <div id='iconci1'>
                            <img src={icon1} alt='' />
                            {/* <img src={icon2} alt='' /> */}
                        </div>
                    </div>
                </div>

                <div id='inform2'>
                    <div id='inform-p1'>
                        {/* <p>6</p>
                        <p>Марина</p>
                        <p>Вероника</p>
                        <p>Петровна</p>
                        <p>20/03/1986</p>
                        <p>Воспитатель</p>
                        <p>15/07/2020</p> */}
                        <div id='iconci1'>
                            <img src={icon1} alt='' />
                            {/* <img src={icon2} alt='' /> */}
                        </div>
                    </div>
                </div>
            </div>
      </div>
    )
  }
}
