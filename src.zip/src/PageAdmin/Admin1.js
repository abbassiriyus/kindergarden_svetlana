import React, { Component } from 'react'

export default class Admin1 extends Component {
  render() {
    return (
      <div>Admin1</div>
    )
  }
}
