import * as React from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box'; 
import './AllAdmin.css'

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export default function BasicTabs() {
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <div className='Addpp'>
    <div className='body'>
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
           {/* <a href='/Addchilldren'><Tab label="Информация о ребенке" {...a11yProps(0)} /></a> */}
           <a href='/Groupchill'><Tab label="Представители" {...a11yProps(1)} /></a>
           <a href='/Educations'><Tab label="Обучение" {...a11yProps(2)} /></a>
           <a href='/'><Tab label="Медицинское заключение" {...a11yProps(2)} /></a>
           <a href='/'><Tab label="Документы" {...a11yProps(2)} /></a>
        </Tabs>
      </Box>
    </Box>
           <div className='bigainp'>
           <div className='inpo1'>
   
           <div className='inblock'>
           <label className='labil'>Фамилия </label><br/>
           <input className='inputlar1' type='text' />
           </div>
   
           <div className='inblock'>
           <label className='labil'>Имя </label><br/>
           <input className='inputlar1' type='text' />
           </div>
   
           <div  className='inblock'>
           <label className='labil'>Отчество </label><br/>
           <input className='inputlar1' type='text' />
           </div>
   
           </div>
   
   
         <div className='inpo2'>
         <div className='inblock'>
           <label className='labil'>Статус </label><br/>
           <input className='inputlar1' type='text' /><br/>
           </div>
   
           <div className='inblock'>     
             <label className='labil'>Место работы</label><br/>
           <input className='inputlar1' type='text' /><br/> 
           </div>
   
   
           <div className='inblock'>        
           <label className='labil'>Телефон</label><br/>
           <input className='inputlar1' type='text' /><br/> 
           </div>
   
         </div>
   
   
   
   
   
   
           <div className='inpo3'>
                 
           <div className='inblock'>
           <label className='labil'>Эл.почта</label><br/>
           <input className='inputlar1' type='text' /><br/> 
           </div>
   
           <div className='inblock'>
           <label className='labil'>Сериа паспорта</label><br/>
           <input className='inputlar1' type='text' /><br/>
           </div>
     
           <div className='inblock'>
           <label className='labil'>Номер паспорта</label><br/>
           <input className='inputlar1' type='text' /><br/>
           </div>
   
           </div>
   
          
   
           <div className='inpo4'>
           <div className='inblock'>      
           <label className='labil'>Дата выдочи</label><br/>
           <input className='inputlar1' type='text' placeholder='Город' />
           </div>
   
           <div className='inblock'>
           <label className='labil'>Адресс регистратции *</label><br/>
             <input className='inputlar1' type='text' placeholder='Улица' />
           </div>
           
           <div className='inblock'>
           <label className='labil'>Адресс регистратции *</label><br/>
             <input className='inputlar1' type='text' placeholder='Номер дома' />
           </div>
           
           </div>
   
           <div className='inpo5'>
            <div className='inblock'>
            <input className='inputlar1' type='text' placeholder='Строение' />
            </div>
            <div className='inblock'>
            <input className='inputlar1' type='text' placeholder='Квартира' />
            </div>
           </div>
   
           <form id="upload-container" method="POST" action="send.php">
               
               <div>
                    <label for="file-input"></label>
                    <input id="file-input" type="file" name="file" multiple/>
                    <span className="span">(Перетащите или щелкните, чтобы вставить)</span>
                   
               </div>
               </form>
   
               <a href='/'><button id="btnlar12">  + Добавить представителя</button></a>
               <div className='kottabtnchi'>
               <button className='btnchi1'>Назад</button>
           <button className='btnchi2'>Сохранить</button> 
           </div>
           </div>
           
         </div>
    
    </div>

  );
}