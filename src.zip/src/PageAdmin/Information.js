import React, { Component } from 'react'
import '../css/Information.css'
import Textlar from './textlar.js'

export default class apple extends Component {
  render() {
    return (
      <div>
        <Textlar />
       <div className='bigbox'>
       <div className="inp_block1">
                    <div>
                    <div className="span_inpblock1">
                   <label className="labled1" for="dobov1">Должность *</label>
                   <input type="text" className="input1" id="dobov1"/>
                   </div>

                   <div className="span_inpblock1">
                   <label className="labled1" for="dobov1">Оброзования *</label>
                   <input type="text" className="input2" id="dobov2"/>
                   </div>

                   <div className="span_inpblock1">
                   <label className="labled1" for="dobov1">Дата приема *</label>
                   <input type="text" className="input3" id="dobov3"/>
                   </div>
                    </div>
               </div> 
              <div className="inp_block2">
                 <div>
                 <div className="span_inpblock2">
                   <label className="labled1" for="dobov1">Дата увольнения *</label>
                   <input type="text" className="input4" id="dobov4"/>
                   </div>

                   <div className="span_inpblock2">
                   <label className="labled1" for="dobov1">Дата выдочи мед.справки *</label>
                   <input type="text" className="input5" id="dobov5"/>
                   </div>

                   <div className="span_inpblock3">
                   <label className="labled1" for="dobov1">Крусы/ Сертификаты *</label>
                   <input type="text" className="input6" id="dobov6"/>
                   </div>
                 </div>
              </div>   
              <div className='kottabtnchi'>
            <a href='/contact'><button className='btnchi1'>Назад</button></a>
        <button className='btnchi2'>Сохранить</button> 
        </div>
       </div>
      </div>
    )
  }
}
