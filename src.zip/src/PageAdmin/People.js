import React, {  } from 'react'
import '../css/people.css'

      
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';

export default function People() {
  const [value, setValue] = React.useState(0);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <div>
    <Box sx={{ width: '100%' }}>
      <Tabs
        onChange={handleChange}
        value={value}
        aria-label="Tabs where each tab needs to be selected manually"
      >
        <Tab label="Основная информация" />
        <Tab href='/contact' label="Контакты" />
        <Tab label="Информация о работе" />
      </Tabs>
    </Box>
<div className='body'>
         {/* <div className='texsti'>
      <h2>Основная информация </h2>
         <a href='/contact'><h2>Контакты</h2></a>lllllllllll
        <a href='/'><h2>Информация о работе</h2></a>
      </div>
      <div className='borderlar'></div> */}
      <div className='katta-pages'>
      <div className='inputlar'>

        <div className='inplar'>
        <label>Фамилия *</label><br/>
        <input type='text'  className='inpuylar1'/><br/>
        </div>

        <div className='inplar'>
        <label>Имя *</label><br/>
        <input type='text'  className='inpuylar1' /><br/>
        </div>

        <div className='inplar'>
        <label>Отчество *</label><br/>
        <input type='text'  className='inpuylar1' /><br/>
        </div>
      </div>

      <div className='inplar2'>
      <div className='inplar1'>
        <label>Пол *</label><br/>
        <input type='text'  className='inpuylar1' /><br/>
        </div>
        
        <div className='inplar1'>
        <label>Дата Рождения *</label><br/>
        <input type='text'  className='inpuylar1' />
        </div>
        
      </div>
        <div className='kattalar2'>
          <label>Фото</label><br/>
          <input type='text' className='kattalar2-inp'  placeholder='(Перетащите или щелкните, чтобы вставить)' />
          <div className='kottabtnchi'>
         <a href='/employ'><button className='btnchi1'>Назад</button></a>
        <button className='btnchi2'>Сохранить</button>
        </div>
        </div>


      </div>
      </div>
    </div>
  )
}


