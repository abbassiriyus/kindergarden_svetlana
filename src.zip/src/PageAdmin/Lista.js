import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import Dropdown from 'react-bootstrap/Dropdown';
import icon1 from '../icon1.svg'
import icon2 from '../icon2.svg'
import '../css/List.css'

export default class Listchill extends Component {
  render() {
    return (
      <div>
        <h1 className='bigah1'>Список детей</h1>
            <div className="biga-pages">
            <Dropdown id="drop">
                    <Dropdown.Toggle variant="light" id="dropdown-basic">
                    Группа
                    </Dropdown.Toggle>

                    <Dropdown.Menu>
                        <Dropdown.Item href="#/action-1">Добавите</Dropdown.Item>
                        <Dropdown.Item href="#/action-2">Добавите</Dropdown.Item>
                        <Dropdown.Item href="#/action-3">Добавите</Dropdown.Item>
                    </Dropdown.Menu>
                </Dropdown>

                <Dropdown id="drop">
                    <Dropdown.Toggle variant="light" id="dropdown-basic">
                    Дата добавления
                    </Dropdown.Toggle>

                    <Dropdown.Menu>
                        <Dropdown.Item href="#/action-1">Добавите</Dropdown.Item>
                        <Dropdown.Item href="#/action-2">Добавите</Dropdown.Item>
                        <Dropdown.Item href="#/action-3">Добавите</Dropdown.Item>
                    </Dropdown.Menu>
                </Dropdown>


                <a href='/'><button id="btnlar1">  + Добавить группу </button></a>
            </div>
            <div id='tables'>
                <div id='names'>
                    <p>ID</p>
                    <p>Фамилия</p>
                    <p>Имя</p>
                    <p>Отчество</p>
                    <p>Дети</p>
                    <p>Телефон</p>
                    <p>Дата <br/> добавления</p>
                    <p>Действие</p>

                </div>
                <div id='inform1'>
                    <div id='inform-p'>
                        <p>1</p>
                        <p>Малина</p>
                        <p>Ирина</p>
                        <p>Евгеньевна</p>
                        <p>Малинина Наташа Малинин Егор</p>
                        <p>+7(910)134-56-22</p> 
                        <p>15/07/2020</p> 

                        <div id='iconci'>
                            <img src={icon1} alt='' />
                            <img src={icon2} alt='' />
                        </div>
                    </div>
                </div>

                <div id='inform2'>
                    <div id='inform-p'>
                        <p>2</p>
                        <p>Малина</p>
                        <p>Ирина</p>
                        <p>Евгеньевна</p>
                        <p>Малинина Наташа Малинин Егор</p>
                        <p>+7(910)134-56-22</p>
                        <p>15/07/2020</p>

                        <div id='iconci'>
                            <img src={icon1} alt='' />
                            <img src={icon2} alt='' />
                        </div>
                    </div>
                </div>

 <div id='inform1'>
                    <div id='inform-p1'>
                        {/* <p>5</p>
                        <p>Тарелкина</p>
                        <p>Вероника</p>
                        <p>Петровна</p>
                        <p>20/03/1986</p>
                        <p>Воспитатель</p>
                        <p>15/07/2020</p> */}
                        <div id='iconci1'>
                            <img src={icon1} alt='' />
                            <img src={icon2} alt='' />
                        </div>
                    </div>
                </div>

                <div id='inform2'>
                    <div id='inform-p1'>
                        {/* <p>4</p>
                        <p>Смирнова</p>
                        <p>Вероника</p>
                        <p>Петровна</p>
                        <p>20/03/1986</p>
                        <p>Воспитатель</p>
                        <p>15/07/2020</p> */}
                        <div id='iconci1'>
                            <img src={icon1} alt='' />
                            <img src={icon2} alt='' />
                        </div>
                    </div>
                </div>

                <div id='inform1'>
                    <div id='inform-p1'>
                        {/* <p>5</p>
                        <p>Тарелкина</p>
                        <p>Вероника</p>
                        <p>Петровна</p>
                        <p>20/03/1986</p>
                        <p>Воспитатель</p>
                        <p>15/07/2020</p> */}
                        <div id='iconci1'>
                            <img src={icon1} alt='' />
                            <img src={icon2} alt='' />
                        </div>
                    </div>
                </div>

                <div id='inform2'>
                    <div id='inform-p1'>
                        {/* <p>6</p>
                        <p>Марина</p>
                        <p>Вероника</p>
                        <p>Петровна</p>
                        <p>20/03/1986</p>
                        <p>Воспитатель</p>
                        <p>15/07/2020</p> */}
                        <div id='iconci1'>
                            <img src={icon1} alt='' />
                            <img src={icon2} alt='' />
                        </div>
                    </div>
                </div>
            </div>
      </div>
    )
  }
}
