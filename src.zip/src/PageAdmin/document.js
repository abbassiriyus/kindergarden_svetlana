import * as React from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import icos from '../ics.svg'
import '../css/document.css'

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export default function BasicTabs() {
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <div className='bodys'>
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
           <a href='/'><Tab label="Документы" {...a11yProps(2)} /></a>
        </Tabs>
      </Box>
    </Box>
    <div className='bigabtnlar'>

<div className='ikkibtn'>
<button>
    <div className='icstex'>
    <img src={icos} alt='' />
    </div>
    Копия свидетельства о рождении
    </button>
    
    <button>
    <div className='icstex'>
    <img src={icos} alt='' />
    </div>
    Медицинский полис
    </button>
</div>

<div className='ikkibtn'>
  <button>
    <div className='icstex'>
    <img src={icos} alt='' />
    </div>
    СНИЛС
    </button>


    <button>
    <div className='icstex'>
    <img src={icos} alt='' />
    </div>
    Справка о регистрации по месту жительства
    </button>
</div>

<div className='ikkibtn'>
<button>
    <div className='icstex'>
    <img src={icos} alt='' />
    </div>
    Паспорт родителя
    </button>

    <button>
    <div className='icstex'>
    <img src={icos} alt='' />
    </div>
    Согласие на обработку персональных данных
    </button>
</div>
</div>
<div className='kottabtnchi'>
            <a href='/Medpo'><button className='btnchi1'>Назад</button></a>
           <button className='btnchi2'>Сохранить</button> 
           </div>

    </div>
  );
}