import React, { Component } from 'react'
import {  Container, Form, Nav, Navbar, NavDropdown } from 'react-bootstrap'
import accountImg from "../img/free-icon-user-149071 1.png"
import logoimg from '../img/Group 109.png'
import  "../css/Navbar.css";
import { FaPhone } from "react-icons/fa"
import { TbBrandTelegram } from 'react-icons/tb'
import { SlSocialVkontakte } from 'react-icons/sl'
import { Link } from 'react-router-dom';
export default class Navbar1 extends Component {

openModal11(){
    document.querySelector(".pageUser11").style="display:block"
    document.querySelector(".pageUser112").style = "display:block"
}
closeModal11() {
    document.querySelector(".pageUser11").style = "display:none"
    document.querySelector(".pageUser112").style = "display:none"
    }
  render() {
    return (
        <div> <Navbar className="Navbar11" expand="lg">
            <Container>
                <Navbar.Brand href="#" ><img className='logoimg11' src={logoimg} alt="" /> </Navbar.Brand>
                <div id="pageUser112" className='minimodal11' href="#">
                    <img alt="" onMouseEnter={() => { this.openModal11() }} src={accountImg} />
                    <div onMouseLeave={() => { this.closeModal11() }} className="pageUser112">
                        <p>Солнцева
                            Татьяна
                            Николаевна <img src={accountImg} alt="" /></p>
                        <Link className="nodec11" href="/setting"><p>Настройки</p></Link>
                        <p>Выйти</p>
                    </div>
                </div>
                <Navbar.Toggle aria-controls="navbarScroll" />
                <Navbar.Collapse id="navbarScroll">
                    <Nav
                        className="m-auto my-2 my-lg-0"
                        navbarScroll
                    >
                        <NavDropdown title="О нас" id="navbarScrollingDropdown">
                            <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
                            <NavDropdown.Item href="#action4">
                                Another action
                            </NavDropdown.Item>
                            <NavDropdown.Divider />
                            <NavDropdown.Item href="#action5">
                                Something else here
                            </NavDropdown.Item>
                        </NavDropdown>
                        <NavDropdown title="Расписание" id="navbarScrollingDropdown">
                            <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
                            <NavDropdown.Item href="#action4">
                                Another action
                            </NavDropdown.Item>
                            <NavDropdown.Divider />
                            <NavDropdown.Item href="#action5">
                                dddd
                            </NavDropdown.Item>
                        </NavDropdown>
                        <Nav.Link href="#action1">Программа</Nav.Link>
                        <Nav.Link href="#action2">Новости</Nav.Link>
                        <Nav.Link href="#">
                            Команда
                        </Nav.Link>
                        <Nav.Link href="#">
                            Контакты
                        </Nav.Link>
                        <Nav.Link id="pageUser111" className='minimodal11' href="#">
                        <img alt="" onMouseEnter={()=>{this.openModal11()}}  src={accountImg} />
                        <div  onMouseLeave={()=>{this.closeModal11()}} className="pageUser11">
                                <p>Солнцева
                                    Татьяна
                                    Николаевна <img  src={accountImg} alt="" /></p>
                              <Link className="nodec11" to="/setting"><p>Настройки</p></Link>  
                                <p>Выйти</p>
                        </div>
                        </Nav.Link>
                    </Nav>
                    <Form className="d-block">
                        <span>Саратов, ул. Пугачева д.98/100</span>
                        <div className="cantact11"><FaPhone /><a href="tel:+7 (8452) 57 79 35">+7 (8452) 57 79 35</a>
                            <a href=""><TbBrandTelegram/></a>
                            <a href=""><SlSocialVkontakte/></a>
</div>

                    </Form> 
                 
                </Navbar.Collapse>
               
            </Container>   
           
        </Navbar>
        
        </div>
    )
  }
}
