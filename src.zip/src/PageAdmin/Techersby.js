import '../css/teachersby.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { Component } from 'react'
import Tabes from './tabe'
export default class App extends Component {
  render() {
    return (
<div className="metgala">
    <Tabes />
<div className="amygdala">
   <select className='bts' name="" id="">
      <option value="">Малинина Виктория Петровна</option>
      <option value="">Малинина Виктория Петровна</option>

      <option value="">Малинина Виктория Петровна</option>

      <option value="">Малинина Виктория Петровна</option>

   </select>
   <input className='bt21' type="date" />
</div>
<div className="nood">
<p className="nod">
Малинина Виктория Петровна
</p>
<p className="nod2">
2023/01/23 - 2023/01/29
</p>
</div>
           <div className=" bigbox">  
                        <div className="bodyadmpn" >

                   <div className="btnadmp_box1">
                        <table className="btnchil_table">
                          <tr className="btnadmp_tr">
       
                             <th className="btnadmp_th1"></th>
                             
                             <th className="btnadmp_th"> ПН</th>
                             <th className="btnadmp_th">ВТ</th>
                             <th className="btnadmp_th">СР</th>
                             <th className="btnadmp_th">ЧТ</th>
                             <th className="btnadmp_th">ПТ</th>
                             <th className="btnadmp_th">СБ</th>
                             <th className="btnadmp_th2">ВС</th>
                            
                        

                          </tr>

                          <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1">09.00 - 09.25 </td>
                             <td className="btnadmp_td1">   </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1"></td>
                             <td className="btnadmp_td1"></td>
                             <td className="btnadmp_td1"></td>
                             <td className="btnadmp_td1"></td>
                       
     

                             <td className="btnadmp_td1"> 
                         
                             </td>
                                </tr>
                          
                                <tr  className="btnadmp_tr1" >
                                  <td className="btnadmp_td2"> 09.35 - 10.00 </td>
                             <td className="btnadmp_td2"> Волшебник 1 <br /> уровня <br /> Эмоции <br /> каб.2 </td>
                             <td className="btnadmp_td2">  </td>
                             <td className="btnadmp_td2"> Волшебник 2 <br />  уровня <br /> Эмоции <br /> каб.2</td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"> Волшебник 1 <br />  уровня <br /> Эмоции <br /> каб.2</td>
                             <td className="btnadmp_td2"></td>
                   
                            

               <td className="btnadmp_td2"> 
                             
                             </td>
                                </tr>
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1">10.00 - 10.25</td>
                             <td className="btnadmp_td1">   Волшебник 3  <br /> уровня <br /> Первые открытия <br /> каб.2 </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1"> Волшебник 3  <br /> уровня <br /> Первые открытия <br /> каб.2 </td>
                             <td className="btnadmp_td1"></td>
                             <td className="btnadmp_td1"> Волшебник 3  <br /> уровня <br /> Первые открытия <br /> каб.2 </td>
                             <td className="btnadmp_td1"></td>

<td className="btnadmp_td1"> 
                         
                             </td>
                                </tr>
                                <tr  className="btnadmp_tr1" >
                                  <td className="btnadmp_td2">10.35 - 11.00 </td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2">  </td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"> </td>
                             <td className="btnadmp_td2"></td>
                   
                            

               <td className="btnadmp_td2"> 
                             
                             </td>
                                </tr>
                       
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1">15.05 - 15.30</td>
                             <td className="btnadmp_td1">  Волшебник 2 <br /> уровня <br /> Доброта <br /> каб.2 </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1">Волшебник 2 <br /> уровня <br /> Доброта <br /> каб.2 </td>
                             <td className="btnadmp_td1"></td>
                             <td className="btnadmp_td1">Волшебник 2 <br /> уровня <br /> Доброта <br /> каб.2 </td>
                             <td className="btnadmp_td1"></td>
                       
     

                             <td className="btnadmp_td1"> 
                         
                             </td>
                                </tr>
                            
                                <tr  className="btnadmp_tr1" >
                                  <td className="btnadmp_td2">15.05 - 15.30 </td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2">  </td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"></td>
                             <td className="btnadmp_td2"> </td>
                             <td className="btnadmp_td2"></td>
                   
                            

               <td className="btnadmp_td2"> 
                             
                             </td>
                                </tr>
                                <tr  className="btnadmp_tr1" >
                             <td className="btnadmp_td1">15.05 - 15.30 </td>
                             <td className="btnadmp_td1">   </td>
                             <td className="btnadmp_td1">  </td>
                             <td className="btnadmp_td1"></td>
                             <td className="btnadmp_td1"></td>
                             <td className="btnadmp_td1"></td>
                             <td className="btnadmp_td1"></td>
                       
     

                             <td className="btnadmp_td1"> 
                         
                             </td>
                                </tr>
                    
                            
                           
                     
                        </table>
                   </div>
            </div>
           </div>

</div>
          )
        }
      
      }