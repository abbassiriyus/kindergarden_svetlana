import React, { Component } from 'react';
import '../css/Addchill.css'
import Tabs from '../pages/tabs.js'


export default class App extends Component {
  render() {
    return (
      <div className='body'>
        <Tabs />
        <div className='bigainp'>
        <div className='inpo1'>

        <div className='inblock'>
        <label className='labil'>Фамилия *</label><br/>
        <input className='inputlar1' type='text' />
        </div>

        <div className='inblock'>
        <label className='labil'>Имя *</label><br/>
        <input className='inputlar1' type='text' />
        </div>

        <div  className='inblock'>
        <label className='labil'>Отчество *</label><br/>
        <input className='inputlar1' type='text' />
        </div>

        </div>


      <div className='inpo2'>
      <div className='inblock'>
        <label className='labil'>Пол *</label><br/>
        <input className='inputlar1' type='text' /><br/>
        </div>

        <div className='inblock'>     
          <label className='labil'>Дата рождения *</label><br/>
        <input className='inputlar1' type='text' /><br/> 
        </div>


        <div className='inblock'>        
        <label className='labil'>Родители *</label><br/>
        <input className='inputlar1' type='text' /><br/> 
        </div>

      </div>






        <div className='inpo3'>
              
        <div className='inblock'>
        <label className='labil'>Свидетельство о рождении *</label><br/>
        <input className='inputlar1' type='text' /><br/> 
        </div>

        <div className='inblock'>
        <label className='labil'>СНИЛС *</label><br/>
        <input className='inputlar1' type='text' /><br/>
        </div>
  
        <div className='inblock'>
        <label className='labil'>Полиос ОМС *</label><br/>
        <input className='inputlar1' type='text' /><br/>
        </div>

        </div>

       

        <div className='inpo4'>
        <div className='inblock'>      
        <label className='labil'>Адресс регистратции *</label><br/>
        <input className='inputlar1' type='text' placeholder='Город' />
        </div>

        <div className='inblock'>
        <label className='labil'>Адресс регистратции *</label><br/>
          <input className='inputlar1' type='text' placeholder='Улица' />
        </div>
        
        <div className='inblock'>
        <label className='labil'>Адресс регистратции *</label><br/>
          <input className='inputlar1' type='text' placeholder='Номер дома' />
        </div>
        
        </div>

        <div className='inpo5'>
         <div className='inblock'>
         <input className='inputlar1' type='text' placeholder='Строение' />
         </div>
         <div className='inblock'>
         <input className='inputlar1' type='text' placeholder='Квартира' />
         </div>
        </div>

        <form id="upload-container" method="POST" action="send.php">
            
            <div>
                 <label for="file-input"></label>
                 <input id="file-input" type="file" name="file" multiple/>
                 <span className="span">(Перетащите или щелкните, чтобы вставить)</span>
                
            </div>
            </form>


            <div className='kottabtnchi'>
            <button className='btnchi1'>Назад</button>
        <button className='btnchi2'>Сохранить</button> 
        </div>
        </div>
        
      </div>
    )
  }
}


