import React from 'react'
import '../css/Contact.css'
import Textlar from './textlar.js'


export default function Contact() {
  return (
    <div>
      <Textlar />
      <div className='body'>
      <div className='contact-big-inp'>
        <div className='contact-inp1'>

          <div className='pop'>
          <label>Серия паспорта *</label><br/>
          <input type='text'/>
          </div>

          <div className='pop'>
          <label>Номер паспорта *</label><br/>
          <input type='text'/><br/>
          </div>

          <div className='pop'>
          <label>Дата выдочи *</label><br/>
          <input type='text'/>
          </div>

        </div>
        <div className='contact-inp2'>

          <div className='pop'>
          <label>Телефон *</label><br/>
          <input type='text'/><br/>
          </div>

          <div className='pop'>
          <label>Эл.почта *</label><br/>
          <input type='text'/>
          </div>
        </div>

        <div className='contact-inp3'>
          <div className='pop'>
          <label>Адрес регистрации*</label><br/>
          <input type='text' style={{"padding-left": "10px"}} placeholder='Город'/><br/>
          </div>

          <div className='pop'>
          <input type='text' id='pop-inp' style={{"padding-left":"10px","margin-top":"20px"}}  placeholder='Улица'/><br/>
          </div>

          <div className='pop'>
          <input type='text' id='pop-inp' style={{"padding-left": "10px", "margin-top":"20px"}}  placeholder='Номер дома'/><br/>
          </div>
        </div>


        <div className='contact-inp4'>
          <div className='pop'>
          <input type='text' style={{"padding-left": "10px", }} placeholder='Город'/><br/>
          </div>

          <div className='pop'>
          <input type='text' id='pop-inp' style={{"padding-left":"10px", }}  placeholder='Улица'/><br/>
          </div>
        </div>
        <div className='kottabtnchi'>
         <a href='/people'><button className='btnchi1'>Назад</button></a>
        <button className='btnchi2'>Сохранить</button>
        </div>
      </div>
      </div>

    </div>
  )
}
