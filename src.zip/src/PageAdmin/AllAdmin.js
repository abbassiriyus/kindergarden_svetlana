import React, { Component } from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Page1 from './Admin1'
import Page2 from './Employee'
import Page3 from './applications'


export default class AllAdmin extends Component {
    render() {
        return (
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Page1 />} />
                    <Route path="/Page2" element={<Page2 />} />
                    <Route path="/Page3" element={<Page3 />} >
                    </Route>
                </Routes>
            </BrowserRouter>
        )
    }
}
